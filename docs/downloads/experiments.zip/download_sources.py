from __future__ import annotations
import base64
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "data/repository_tree.json"

def main():
    tree = json.loads(TREE.read_text())
    selected = [x for x in tree["tree"] if x["type"] == "blob" and (
        x["path"].endswith((".py", ".md")) or
        (x["path"].startswith("data/") and "/noclassification/" not in x["path"] and x["path"].endswith(".mp4")))]
    def download(item):
        target = ROOT / "original" / item["path"]
        if target.exists():
            data = target.read_bytes()
        else:
            raw = subprocess.check_output(["curl", "-fsSL", "--max-time", "40", item["url"]])
            data = base64.b64decode(json.loads(raw)["content"])
        blob_sha = hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()
        if blob_sha != item["sha"]:
            raise ValueError(f"Hash mismatch: {item['path']}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        return {"path": item["path"], "git_blob_sha": blob_sha, "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(download, selected))
    videos = [x for x in tree["tree"] if x["type"] == "blob" and x["path"].endswith(".mp4")]
    aliases = {}
    for item in videos:
        aliases.setdefault(item["sha"], []).append(item["path"])
    manifest = {"repository": "https://github.com/AABBCCDKG/Video_prediction_through_physical_laws", "commit": tree["sha"], "downloads": rows, "video_aliases_by_blob_sha": aliases}
    (ROOT / "data").mkdir(exist_ok=True)
    (ROOT / "data/source_manifest.json").write_text(json.dumps(manifest, indent=2))
    print(f"Verified {len(rows)} source files; {len(videos)} video paths = {len(aliases)} distinct byte sequences")

if __name__ == "__main__":
    main()
