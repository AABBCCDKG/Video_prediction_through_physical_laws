from __future__ import annotations
import json
from pathlib import Path
import time
import cv2
import numpy as np
import torch
from torch import nn

ROOT=Path(__file__).resolve().parent

class ConvLSTMCell(nn.Module):
    def __init__(self,channels=8):
        super().__init__();self.channels=channels
        self.gates=nn.Conv2d(3+channels,4*channels,3,padding=1)
    def forward(self,x,h,c):
        i,f,o,g=self.gates(torch.cat([x,h],dim=1)).chunk(4,dim=1)
        c=f.sigmoid()*c+i.sigmoid()*g.tanh()
        h=o.sigmoid()*c.tanh()
        return h,c

class TinyPredictor(nn.Module):
    def __init__(self):
        super().__init__();self.cell=ConvLSTMCell();self.output=nn.Conv2d(8,3,1)
    def forward(self,prefix):
        b,_,_,height,width=prefix.shape
        h=torch.zeros(b,8,height,width,device=prefix.device);c=torch.zeros_like(h)
        for frame in prefix.unbind(1):h,c=self.cell(frame,h,c)
        return self.output(h).sigmoid()

def main():
    torch.manual_seed(42)
    device='mps' if torch.backends.mps.is_available() else 'cpu'
    sequences=[]
    for variant in [1,2]:
        cap=cv2.VideoCapture(str(ROOT/f'original/data/1/{variant}.mp4'))
        frames=[]
        for _ in range(7):
            ok,frame=cap.read()
            if not ok:raise RuntimeError('Frame missing')
            frames.append(cv2.cvtColor(cv2.resize(frame,(96,54)),cv2.COLOR_BGR2RGB))
        cap.release();sequences.append(np.stack(frames))
    data=torch.from_numpy(np.stack(sequences)).float().permute(0,1,4,2,3).to(device)/255
    model=TinyPredictor().to(device);optimizer=torch.optim.Adam(model.parameters(),lr=.002)
    losses=[];start=time.perf_counter()
    for _ in range(20):
        prediction=model(data[:,:6]);loss=(prediction-data[:,6]).square().mean()
        optimizer.zero_grad();loss.backward();optimizer.step()
        losses.append(float(loss.detach().cpu()))
    if device=='mps':torch.mps.synchronize()
    result={'status':'smoke_test_only','device':device,'torch':torch.__version__,'parameters':sum(p.numel() for p in model.parameters()),'input_shape':list(data[:,:6].shape),'steps':20,'first_loss':losses[0],'last_loss':losses[-1],'finite_losses':all(np.isfinite(losses)),'runtime_seconds':time.perf_counter()-start,'split':'Two scene-1 clips fitted on the same batch; no validation/test claim','not_a_benchmark':True}
    (ROOT/'results/learning_preflight.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
