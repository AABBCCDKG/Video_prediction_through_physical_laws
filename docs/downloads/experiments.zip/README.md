# Experiments — execution record

Date: 2026-10-16 (America/Los_Angeles).

The user authorized checking and running missing experiments. The files in this directory are research working material; they are not included in the manuscript source ZIP. The historical pilot remains diagnostic. The paper now includes the separately measured exploratory grouped experiment described in `results/formal/RESULTS.md`; pilot numbers are not used as final measurements.

## Verified execution

- Source commit: `b596d003f737f40a62ea74a98adba001243bc9cb`. Downloaded 27 original source/code files with Git blob and SHA-256 checks. Original files are preserved unchanged under `original/`.
- Repository video inventory: 40 paths, 20 different byte sequences, organized as 10 paired scene groups. The `noclassification/` entries are identical copies, not additional recordings.
- All 20 videos decode at 1280×720 and 59.94005994 fps; 2,499 total frames, about 41.69 seconds. Repository prefixes range from 3 to 51 frames.
- Python 3.11.15 environment with frozen package versions is in `.venv/` and `requirements-lock.txt`.
- Apple GPU (MPS) matrix calculation passed. A 3,227-parameter ConvLSTM with two real video prefixes completed 20 forward/backward steps in about 1.4 seconds. Training loss was finite and decreased on the same batch. This is a capacity check, not a held-out result.
- Original scene 1/1 ran 60 updates at the original dt=0.25. Only path substitution and a bounded headless loop were applied. This proves execution, not timestamp-correct prediction.
- Headless diagnostic runner completed all 20 videos with 8 methods and 30-frame horizons. It aligns fitted states to the final input timestamp and uses four physics substeps per video frame.
- Controlled checks passed for simulation time, zero-speed stopping without reversal, and a two-body contact response.

## Diagnostic measurements

Labels come from the same Hough detector with causal Hungarian matching. They are not independent annotations. These numbers must not be used as verified paper results.

| Method | All-object ADE (px) | FDE (px) | Prefix-moving-object ADE (px) |
|---|---:|---:|---:|
| persistence | 40.43 | 56.32 | 123.84 |
| linear | 44.00 | 80.93 | 142.37 |
| quadratic | 79.58 | 187.47 | 154.92 |
| physics_constant_acceleration | 58.78 | 158.13 | 92.63 |
| physics_deceleration | 13.30 | 26.41 | 37.35 |
| physics_constant_velocity | 14.93 | 29.76 | 26.07 |
| physics_deceleration_no_contacts | 35.00 | 60.30 | 105.62 |
| physics_constant_velocity_no_contacts | 43.90 | 82.21 | 122.91 |

ADE averages errors over 30 future frames and objects; scene means give each paired scene equal weight. Prefix-moving objects use a provisional linear prefix speed threshold >1 px/frame, so this stratum misses objects that are stationary until contact. The FDE refers to the final future frame.

With the same quadratic initial states and deceleration rule, enabling contacts lowered provisional scene-mean ADE from 35.00 to 13.30 px. For constant-velocity simulation initialized from the same quadratic fit, the corresponding comparison was 43.90 to 14.93 px. This isolates the contact switch within the diagnostic implementation. It does not validate object identities or physical parameters.

The method ordering changes when considering prefix-moving objects: contact simulation with constant velocity has 26.07 px vs 37.35 px for the deceleration rule. No final method or parameter selection has been made.

## Limits of this run

- Future center coverage over the pilot horizon averages 97.4%, with a minimum of 89.2%. Missing targets are excluded in provisional ADE, so it is optimistic. Objects absent in the first frame cannot enter a track.
- In 18 of 20 clips, detected object count changes over the full video. Some balls are clipped by the frame; the contact sheet shows a pocket detected as a circle and missed balls. Independent identity, radius, presence and event checks are needed.
- No table boundaries or pockets are simulated. Screen coordinates are treated as planar; calibration is unverified.
- The original update uses frame-index dynamics and an unaligned dt, plus source-documented acceleration-update problems. The new runner is a corrected reference, not an exact historical reproduction.
- New runner differences: Hungarian association, no dummy zero-coordinate imputations, last-observation initialization, explicit fps, four substeps, selectable acceleration rule, no R²-based forced stationary classification. These must be disclosed and stabilized for final experiments.
- All scene groups have been inspected in this pilot. A later split is a predeclared grouped rerun, not a pristine unseen-test claim. New unseen recordings are preferred for a stronger confirmatory evaluation.
- No trained-baseline validation, independent test, trained renderer, physical-consistency event score, confidence interval, or learning curve is claimed.

## Files and reproduction

- `data/source_manifest.json`: source revision, checksums and duplicate-video mapping.
- `data/video_manifest.json`: frame rate, dimensions, lengths and existing prefixes.
- `results/original_run.json`: bounded original execution.
- `results/learning_preflight.json`: Apple GPU neural-training check.
- `results/pilot_metrics.csv`, `pilot_summary.json`, `pilot_analysis.json`: all provisional numbers.
- `results/tracking_quality.json`: object detection and track availability checks.
- `results/source_contact_sheet.jpg`, `pilot_comparison.png`, `scene1_prediction_overlay.jpg`: diagnostic visuals.
- `TODO.md`: prioritized remaining experiment work.

```bash
uv venv --python 3.11 experiments/.venv
uv pip install --system-certs --python experiments/.venv/bin/python -r experiments/requirements-lock.txt
experiments/.venv/bin/python experiments/download_sources.py
experiments/.venv/bin/python experiments/preflight.py
experiments/.venv/bin/python experiments/check_original.py
experiments/.venv/bin/python experiments/check_learning.py
experiments/.venv/bin/python experiments/run_pilot.py
experiments/.venv/bin/python experiments/analyze_pilot.py
```

The unchanged source files are read/downloaded, never pushed or committed to the upstream repository.

## Completed grouped experiment

The user declined additional recording and authorized completing the work from current videos. The current deliverables are `results/formal/RESULTS.md`, `results/formal/metrics.csv`, `results/formal/report.json`, three loadable ConvLSTM checkpoints and complete logs, final reference measurements in `data/labels/`, and updated paper tables/figures. Group split:1–6 training,7–8 validation,9–10 evaluation, paired clips together. Previous inspection of every group is disclosed.

Reference measurements use HSV foreground components/ellipse fits and local template matching separately from Hough predictions. All20 clips' first, prefix-end and future keyframes and candidate contact images were inspected by the assistant. Corrections include the shaded cue-ball seed at(185,442), radius31; a distorted radius in10/1; event object IDs; and loss-of-view/foreground-support masks. They are image measurements with keyframe review, not externally certified annotations or game-engine ground truth. The measured subset has88 first-frame object slots;16 slots appear in the four evaluation clips.

Geometry methods are Hough-detected from the observed prefix only, with endpoint-anchored association and a static fallback for fewer than three observations. All geometry methods report15/30/60-frame metrics, moving-object strata, target coverage, prediction misses, penetration, and near-contact counts. The empirical cohort excludes objects not separated in the reference measurement. Full geometry scoring uses the image-diagonal penalty for a missing predicted object; target measurements unavailable from the image are excluded with explicit coverage. Neural detector-based center scores remain diagnostic.

ConvLSTM:one16-channel convolutional recurrent layer,3×3 kernels,11,443 parameters,160×90 RGB; Adam0.001, batch4,10-frame autoregressive training rollout. Seeds0/1/2 completed2000 updates; validation chooses checkpoints at1900/2000/2000. The initial400-update run is archived in `results/formal_budget400/`; the validation-driven extension is declared in `protocol_extended.json`. Neither an untouched external test nor large-model superiority is claimed.

Thirty-frame evaluation:constant-velocity contact simulation ADE12.42px, FDE21.24px; matched no-contact ADE42.92px; quadratic41.19px; deceleration14.02px. Moving-object ADE is28.91px versus92.90px without contacts. Reference center coverage is99.79% in the four evaluated clips; all reference identities match a prefix prediction. Per-group constant-velocity ADE is8.17px(group9) and16.66px(group10). This is limited to2 evaluation groups.

Complete-frame RGB MSE:physics0.001150, persistence0.002162, ConvLSTM0.002727±0.000226 across seeds. Mean per-clip PSNR:29.52dB,26.80dB,25.85±0.30dB, respectively. Seed variation does not represent scene-level uncertainty. Low-resolution predictions and background-dominated MSE limit interpretation.

Reproduce final work:

```bash
experiments/.venv/bin/python experiments/build_labels.py
experiments/.venv/bin/python experiments/train_convlstm.py --protocol protocol_extended.json
experiments/.venv/bin/python experiments/benchmark.py
experiments/.venv/bin/python experiments/report_results.py
experiments/.venv/bin/python experiments/generate_paper_tables.py
experiments/.venv/bin/python experiments/validate.py
tectonic --untrusted --keep-logs --keep-intermediates --outdir paper/build paper/main.tex
```

The archived checkpoints and forecasts avoid the need to retrain simply to inspect results. MPS kernels can introduce small numerical variation across machines/runs. A source/data/checkpoint/results reproducibility ZIP is saved at `purdue-motion-experiments.zip`; it excludes the virtual environment and large raw-frame caches, which can be regenerated from the included20 videos.
