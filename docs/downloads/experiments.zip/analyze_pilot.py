from __future__ import annotations
import csv
import json
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw

ROOT=Path(__file__).resolve().parent

def main():
    with (ROOT/'results/pilot_metrics.csv').open() as f:rows=list(csv.DictReader(f))
    methods=list(dict.fromkeys(r['method'] for r in rows))
    aggregates={}
    for method in methods:
        subset=[r for r in rows if r['method']==method]
        moving=[]
        for group in sorted({r['scene_group'] for r in subset},key=int):
            values=[float(r['moving_ADE_px']) for r in subset if r['scene_group']==group and r['moving_ADE_px']]
            if values:moving.append(float(np.mean(values)))
        aggregates[method]={'ADE_px':float(np.mean([float(r['ADE_px']) for r in subset])),'FDE_px':float(np.mean([float(r['FDE_px']) for r in subset if r['FDE_px']])),'moving_ADE_px':float(np.mean(moving)) if moving else None}
    ablations={}
    for with_contacts,without in [('physics_deceleration','physics_deceleration_no_contacts'),('physics_constant_velocity','physics_constant_velocity_no_contacts')]:
        differences={}
        for group in range(1,11):
            a=np.mean([float(r['ADE_px']) for r in rows if r['method']==with_contacts and int(r['scene_group'])==group])
            b=np.mean([float(r['ADE_px']) for r in rows if r['method']==without and int(r['scene_group'])==group])
            differences[group]=float(a-b)
        ablations[with_contacts]={'paired_scene_ADE_change_px':float(np.mean(list(differences.values()))),'scenes_with_lower_error':sum(v<0 for v in differences.values()),'per_scene_change':differences}
    coverage=[float(r['target_coverage']) for r in rows if r['method']=='persistence']
    result={'diagnostic_only':True,'methods':aggregates,'contact_ablations':ablations,'coverage_mean':float(np.mean(coverage)),'coverage_min':min(coverage),'coverage_max':max(coverage)}
    (ROOT/'results/pilot_analysis.json').write_text(json.dumps(result,indent=2))
    width=1180;height=100+len(methods)*55
    image=Image.new('RGB',(width,height),'white');draw=ImageDraw.Draw(image)
    draw.text((20,16),'Diagnostic pilot: 20 recordings / 10 scene groups / 30 future frames',fill='black')
    draw.text((20,37),'Automatic detector measurements; unverified identities; no publication claim',fill='#9b2727')
    for i,(method,value) in enumerate(aggregates.items()):
        y=80+i*55
        draw.text((20,y),method,fill='black')
        bar=int(value['ADE_px']/max(v['ADE_px'] for v in aggregates.values())*450)
        draw.rectangle((370,y,370+bar,y+22),fill='#3678a5')
        draw.text((840,y),f"ADE {value['ADE_px']:.2f} px",fill='black')
        draw.text((840,y+20),f"moving ADE {value['moving_ADE_px']:.2f} px" if value['moving_ADE_px'] else 'moving ADE n/a',fill='#555')
    image.save(ROOT/'results/pilot_comparison.png')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
