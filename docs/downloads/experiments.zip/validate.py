from pathlib import Path
import hashlib
import json
import sys
import numpy as np
from run_pilot import validation
from benchmark import prefix_tracks,render
from train_convlstm import Predictor
import torch
ROOT=Path(__file__).resolve().parent

def main():
 validation()
 with np.load(ROOT/'data/tracks_1_1.npz') as z:frames=z['frames'][:17].copy()
 p,r=prefix_tracks(frames,16);frames[16:]=0;p2,r2=prefix_tracks(frames,16)
 assert np.allclose(p,p2,equal_nan=True) and np.allclose(r,r2,equal_nan=True)
 image=render(frames[:16],p[-1],np.nanmedian(r,axis=0),np.repeat(p[-1:],3,axis=0))
 assert image.shape==(3,90,160,3)
 for row in json.loads((ROOT/'data/source_manifest.json').read_text())['downloads']:
  assert hashlib.sha256((ROOT/'original'/row['path']).read_bytes()).hexdigest()==row['sha256']
 for row in json.loads((ROOT/'data/labels/manifest.json').read_text()):
  key=f"{row['scene_group']}_{row['variant']}"
  with np.load(ROOT/f'data/labels/{key}.npz') as z:
   assert (np.isfinite(z['centers']).all(2)==(z['status']>0)).all()
   for e in row['candidate_events']:assert 0<=e['frame']<len(z['centers']) and max(e['objects'])<len(z['radii'])
 for seed in [0,1,2]:
  path=ROOT/f'results/formal/convlstm_seed{seed}'
  log=json.loads((path/'training_log.json').read_text());summary=json.loads((path/'summary.json').read_text())
  assert len(log)==2000 and summary['updates']==2000
  scored=[r for r in log if 'validation_MSE' in r]
  assert summary['selected_update']==min(scored,key=lambda r:r['validation_MSE'])['update']
  checkpoint=torch.load(path/'best.pt',map_location='cpu',weights_only=False)
  model=Predictor(16);model.load_state_dict(checkpoint['state_dict'])
  with torch.no_grad():forecast=model(torch.zeros(1,3,3,90,160),2)
  assert forecast.shape==(1,2,3,90,160) and torch.isfinite(forecast).all()
 print('Verified source hashes, label consistency, target-independent prefix input, renderer dimensions, 3 complete training logs and validation-selected loadable checkpoints.')
if __name__=='__main__':main()
