from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import random
import time
import cv2
import numpy as np
import torch
from torch import nn

ROOT=Path(__file__).resolve().parent
class Cell(nn.Module):
    def __init__(self,hidden=16):
        super().__init__();self.hidden=hidden
        self.gates=nn.Conv2d(3+hidden,4*hidden,3,padding=1)
    def forward(self,x,state):
        h,c=state;i,f,o,g=self.gates(torch.cat([x,h],1)).chunk(4,1)
        c=torch.sigmoid(f)*c+torch.sigmoid(i)*torch.tanh(g)
        return torch.sigmoid(o)*torch.tanh(c),c
class Predictor(nn.Module):
    def __init__(self,hidden=16):
        super().__init__();self.cell=Cell(hidden);self.readout=nn.Conv2d(hidden,3,3,padding=1)
    def initial(self,x):
        shape=(x.shape[0],self.cell.hidden,*x.shape[-2:])
        return torch.zeros(shape,device=x.device),torch.zeros(shape,device=x.device)
    def forward(self,prefix,horizon):
        state=self.initial(prefix[:,0])
        for x in prefix.unbind(1):state=self.cell(x,state)
        frames=[]
        for k in range(horizon):
            prediction=torch.sigmoid(self.readout(state[0]));frames.append(prediction)
            if k+1<horizon:state=self.cell(prediction,state)
        return torch.stack(frames,1)

def load_videos(protocol,device):
    cache=ROOT/'data/rgb_160_90.npz'
    if cache.exists():
        with np.load(cache) as z:videos={k:z[k] for k in z.files}
    else:
        videos={}
        for group in range(1,11):
            for variant in [1,2]:
                cap=cv2.VideoCapture(str(ROOT/f'original/data/{group}/{variant}.mp4'));frames=[]
                while True:
                    ok,frame=cap.read()
                    if not ok:break
                    frame=cv2.resize(frame,tuple(protocol['convlstm']['resolution']),interpolation=cv2.INTER_AREA)
                    frames.append(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB))
                cap.release();videos[f'{group}_{variant}']=np.stack(frames)
        np.savez_compressed(cache,**videos)
    return {k:torch.from_numpy(v).permute(0,3,1,2).to(device,dtype=torch.float32)/255 for k,v in videos.items()}

@torch.no_grad()
def evaluate(model,videos,manifest,groups,horizon=30):
    model.eval();rows=[];forecasts={}
    for row in manifest:
        if row['scene_group'] not in groups:continue
        key=f"{row['scene_group']}_{row['variant']}";T=row['input_frames_in_repository']
        target=videos[key][T:T+horizon]
        prediction=model(videos[key][:T].unsqueeze(0),len(target))[0]
        mse=float((prediction-target).square().mean().cpu())
        persistence=float((videos[key][T-1:T].expand_as(target)-target).square().mean().cpu())
        rows.append({'key':key,'MSE':mse,'PSNR':-10*np.log10(max(mse,1e-12)),'persistence_MSE':persistence})
        forecasts[key]=(prediction.clamp(0,1).cpu().numpy()*255).round().astype('uint8').transpose(0,2,3,1)
    model.train();return rows,forecasts

def train(seed,protocol,videos,manifest,device):
    cfg=protocol['convlstm'];rng=random.Random(seed);torch.manual_seed(seed)
    np.random.seed(seed);model=Predictor(cfg['hidden_channels']).to(device)
    optimizer=torch.optim.Adam(model.parameters(),lr=cfg['learning_rate'])
    keys=[f'{g}_{v}' for g in protocol['train_groups'] for v in [1,2]]
    result_dir=ROOT/f'results/formal/convlstm_seed{seed}';result_dir.mkdir(parents=True,exist_ok=True)
    rows=[];best=float('inf');start=time.perf_counter()
    for step in range(1,cfg['updates']+1):
        T=rng.choice(cfg['train_prefix_frames']);H=cfg['training_rollout_frames']
        prefixes=[];targets=[]
        for _ in range(cfg['batch_size']):
            key=rng.choice(keys);video=videos[key];offset=rng.randrange(len(video)-T-H+1)
            prefixes.append(video[offset:offset+T]);targets.append(video[offset+T:offset+T+H])
        prediction=model(torch.stack(prefixes),H);target=torch.stack(targets)
        loss=(prediction-target).square().mean()
        if not bool(torch.isfinite(loss).cpu()):raise RuntimeError('Nonfinite loss')
        optimizer.zero_grad();loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1.0);optimizer.step()
        record={'update':step,'training_MSE':float(loss.detach().cpu())}
        if step%cfg['validation_interval_updates']==0:
            valid,_=evaluate(model,videos,manifest,protocol['validation_groups'])
            score=float(np.mean([r['MSE'] for r in valid]));record['validation_MSE']=score
            if score<best:
                best=score;torch.save({'state_dict':model.state_dict(),'seed':seed,'update':step,'validation_MSE':score,'protocol':protocol},result_dir/'best.pt')
            print(f'seed={seed} step={step}/{cfg["updates"]} train={record["training_MSE"]:.6f} val={score:.6f} elapsed={time.perf_counter()-start:.1f}s',flush=True)
            (result_dir/'training_log.json').write_text(json.dumps(rows+[record],indent=2))
        rows.append(record)
    checkpoint=torch.load(result_dir/'best.pt',map_location=device,weights_only=False)
    model.load_state_dict(checkpoint['state_dict'])
    valid,valid_forecasts=evaluate(model,videos,manifest,protocol['validation_groups'],60)
    tests,test_forecasts=evaluate(model,videos,manifest,protocol['test_groups'],60)
    np.savez_compressed(result_dir/'forecasts.npz',**valid_forecasts,**test_forecasts)
    outcome={'seed':seed,'device':device,'torch_version':torch.__version__,'parameters':sum(p.numel() for p in model.parameters()),'updates':cfg['updates'],'selected_update':checkpoint['update'],'validation_MSE_at_30':best,'validation_at_60':valid,'test_at_60':tests,'runtime_seconds':time.perf_counter()-start,'protocol':protocol,'protocol_sha256':hashlib.sha256(json.dumps(protocol,sort_keys=True).encode()).hexdigest()}
    (result_dir/'summary.json').write_text(json.dumps(outcome,indent=2));(result_dir/'training_log.json').write_text(json.dumps(rows,indent=2))
    print('Completed',json.dumps(outcome),flush=True)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--seed',type=int);parser.add_argument('--protocol',default='protocol.json');args=parser.parse_args()
    protocol=json.loads((ROOT/args.protocol).read_text());manifest=json.loads((ROOT/'data/video_manifest.json').read_text())
    torch.set_num_threads(4);cv2.setNumThreads(2);device='mps' if torch.backends.mps.is_available() else 'cpu'
    videos=load_videos(protocol,device)
    seeds=protocol['convlstm']['seeds'] if args.seed is None else [args.seed]
    for seed in seeds:train(seed,protocol,videos,manifest,device)
if __name__=='__main__':main()
