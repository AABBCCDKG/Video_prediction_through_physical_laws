from pathlib import Path
import json
import shutil
ROOT=Path(__file__).resolve().parent
PAPER=ROOT.parent/'paper'

def main():
 report=json.loads((ROOT/'results/formal/report.json').read_text());results=report['heldout_at_30']
 methods=[('persistence','Persistence'),('linear','Linear'),('quadratic','Quadratic'),('physics_constant_velocity_no_contacts','Same state, no contacts'),('physics_constant_velocity','Physics (constant velocity)'),('physics_constant_acceleration','Physics (constant acceleration)'),('physics_deceleration_no_contacts','Deceleration, no contacts'),('physics_deceleration','Physics (deceleration)')]
 lines=[r'\begin{table}[htbp]',r'\caption{Thirty-frame geometric prediction on four evaluation clips in groups 9 and 10. Image-derived reference centers define the measured cohort. Means give equal weight to the two paired groups; moving ADE uses reference displacement only for reporting.}',r'\label{tab:geometry}',r'\centering',r'\begin{tabular}{lrrr}',r'\toprule',r'Method & ADE (px) & FDE (px) & Moving ADE (px) \\',r'\midrule']
 for key,name in methods:
  x=results[key];lines.append(f"{name} & {x['ADE_px']:.2f} & {x['FDE_px']:.2f} & {x['moving_ADE_px']:.2f} \\\\")
 lines.extend([r'\bottomrule',r'\end{tabular}',r'\end{table}',''])
 a=results['physics_constant_velocity'];b=results['physics_constant_velocity_no_contacts'];q=results['quadratic'];d=results['physics_deceleration']
 lines.append(f"At 30 frames, constant-velocity contact simulation has mean ADE {a['ADE_px']:.2f} pixels compared with {b['ADE_px']:.2f} for its matched contact-disabled rollout and {q['ADE_px']:.2f} for quadratic extrapolation. The corresponding moving-object errors are {a['moving_ADE_px']:.2f}, {b['moving_ADE_px']:.2f}, and {q['moving_ADE_px']:.2f} pixels. Deceleration gives {d['ADE_px']:.2f} pixels overall and {d['moving_ADE_px']:.2f} on moving objects. Constant-velocity simulation also has lower validation ADE than deceleration; all variants remain reported.")
 lines.append(f"Reference-measurement coverage averages {a['label_coverage']*100:.2f}\\% across evaluation clips at the primary horizon, and every reference identity is matched by a prefix track. Pair-time penetration exceeding 10\\% of summed radii is {a['overlap_pair_time_rate']*100:.2f}\\% for constant-velocity contact simulation versus {b['overlap_pair_time_rate']*100:.2f}\\% with contacts disabled. These measurements apply to the annotated object subset.")
 lines.extend(['',r'\begin{table}[htbp]',r'\caption{Complete RGB reconstruction at 30 frames and $160\times90$ resolution. PSNR is averaged per clip. ConvLSTM variation is the standard deviation across three seeds, not a scene-level confidence interval.}',r'\label{tab:rgb}',r'\centering',r'\begin{tabular}{lrr}',r'\toprule',r'Method & RGB MSE & PSNR (dB) \\',r'\midrule'])
 selected=['persistence','linear','quadratic','physics_constant_velocity_no_contacts','physics_constant_velocity','physics_deceleration']
 names=dict(methods)
 for key in selected:
  x=results[key];lines.append(f"{names[key]} & {x['RGB_MSE']:.6f} & {x['PSNR_dB']:.2f} \\\\")
 mean=report['convlstm_seed_mean'];sd=report['convlstm_seed_sd']
 lines.append(f"ConvLSTM (3 seeds) & ${mean['RGB_MSE']:.6f} \\pm {sd['RGB_MSE']:.6f}$ & ${mean['PSNR_dB']:.2f} \\pm {sd['PSNR_dB']:.2f}$ \\\\")
 lines.extend([r'\bottomrule',r'\end{tabular}',r'\end{table}',''])
 lines.append(f"The compact ConvLSTM has mean RGB MSE {mean['RGB_MSE']:.6f} compared with {results['persistence']['RGB_MSE']:.6f} for persistence and {a['RGB_MSE']:.6f} for constant-velocity simulation with the shared renderer. Selected checkpoints occur at updates 1,900, 2,000, and 2,000. Its outputs remain blurred in several clips and do not improve on persistence under this image metric. This outcome applies to the stated model and budget, not learned video predictors as a class.")
 lines.extend(['',r'\begin{table}[htbp]',r'\caption{Per-group 30-frame ADE, averaged over paired clips. Two groups do not support a reliable significance claim.}',r'\label{tab:pergroup}',r'\centering',r'\begin{tabular}{rrrr}',r'\toprule',r'Group & Physics (CV) & Same state, no contacts & Quadratic \\',r'\midrule'])
 for group,x in report['per_test_group'].items():lines.append(f"{group} & {x['physics_constant_velocity']['ADE_px']:.2f} & {x['physics_constant_velocity_no_contacts']['ADE_px']:.2f} & {x['quadratic']['ADE_px']:.2f} \\\\")
 lines.extend([r'\bottomrule',r'\end{tabular}',r'\end{table}',''])
 (PAPER/'sections/results_tables.tex').write_text('\n'.join(lines)+'\n')
 for filename in ['qualitative_predictions.png','horizon_ade.pdf']:shutil.copy2(ROOT/'results/formal'/filename,PAPER/'figures'/filename)
 print('Paper tables and figures generated from stored measurements.')
if __name__=='__main__':main()
