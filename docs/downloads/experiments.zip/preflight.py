from __future__ import annotations
import json
from pathlib import Path
import cv2
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent

def main():
    tree = json.loads((ROOT/'data/repository_tree.json').read_text())
    rows=[]
    thumbnails=[]
    for group in range(1,11):
        for variant in [1,2]:
            relative=f'data/{group}/{variant}.mp4'
            cap=cv2.VideoCapture(str(ROOT/'original'/relative))
            if not cap.isOpened():raise RuntimeError(relative)
            fps=cap.get(cv2.CAP_PROP_FPS)
            count=int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            width=int(cap.get(cv2.CAP_PROP_FRAME_WIDTH));height=int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            prefix=f'dataset/{group}/{variant}/input/'
            input_files=[x['path'] for x in tree['tree'] if x['type']=='blob' and x['path'].startswith(prefix) and x['path'].endswith('.jpg')]
            first=None;detections=[]
            for k in sorted(set([0,max(0,len(input_files)-1),min(count-1,len(input_files)+10)])):
                cap.set(cv2.CAP_PROP_POS_FRAMES,k);ok,frame=cap.read()
                if not ok:raise RuntimeError(f'Cannot read {relative} frame {k}')
                gray=cv2.GaussianBlur(cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY),(9,9),2)
                circles=cv2.HoughCircles(gray,cv2.HOUGH_GRADIENT,dp=1.2,minDist=30,param1=50,param2=30,minRadius=15,maxRadius=50)
                circles=np.empty((0,3)) if circles is None else np.round(circles[0]).astype(int)
                detections.append({'frame':k,'circles':circles.tolist()})
                if first is None:
                    display=frame.copy()
                    for x,y,r in circles:cv2.circle(display,(int(x),int(y)),int(r),(0,0,255),2)
                    first=Image.fromarray(cv2.cvtColor(display,cv2.COLOR_BGR2RGB))
            cap.release()
            rows.append({'scene_group':group,'variant':variant,'path':relative,'fps':fps,'frames':count,'width':width,'height':height,'input_frames_in_repository':len(input_files),'sample_detections':detections})
            first.thumbnail((480,280));thumbnails.append((f'Group {group}/{variant}: {count}f @ {fps:.2f}, input={len(input_files)}',first))
    canvas=Image.new('RGB',(1000,10*320),'#eee');draw=ImageDraw.Draw(canvas)
    for i,(label,img) in enumerate(thumbnails):
        x=(i%2)*500+10;y=(i//2)*320+25
        canvas.paste(img,(x,y));draw.text((x,y-20),label,fill='black')
    out=ROOT/'results';out.mkdir(exist_ok=True)
    canvas.save(out/'source_contact_sheet.jpg')
    (ROOT/'data/video_manifest.json').write_text(json.dumps(rows,indent=2))
    for row in rows:print(row['path'],row['width'],row['height'],row['fps'],row['frames'],'input',row['input_frames_in_repository'],'circles',[len(x['circles']) for x in row['sample_detections']])

if __name__=='__main__':main()
