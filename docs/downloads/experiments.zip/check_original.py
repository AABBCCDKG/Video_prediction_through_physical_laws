from __future__ import annotations
import ast
import json
import os
from pathlib import Path
import sys
import traceback

os.environ['SDL_VIDEODRIVER']='dummy'
os.environ['SDL_AUDIODRIVER']='dummy'
os.environ['PYGAME_HIDE_SUPPORT_PROMPT']='1'
import cv2
import numpy as np

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'original'))
from physicalengine import PhysicsEngine

def main():
    inputs=ROOT/'data/original_scene1_input';inputs.mkdir(parents=True,exist_ok=True)
    cap=cv2.VideoCapture(str(ROOT/'original/data/1/1.mp4'))
    for i in range(16):
        ok,frame=cap.read()
        if not ok:raise RuntimeError('Missing input')
        cv2.imwrite(str(inputs/f'frame_{i:05d}.jpg'),frame)
    cap.release()
    result={'scene':'1/1','input_frames':16,'source_code_unchanged':True,'adaptations':['Replace two absolute paths with verified local inputs','Replace indefinite GUI loop with 60 updates using the original dt=0.25','Raise on invalid floating-point arithmetic to prevent native NaN simulation']}
    def bounded_run(self):
        result['initial_states']=[{'position':list(body.position),'velocity':list(body.velocity),'acceleration':list(accel)} for body,accel,_,_ in self.balls]
        with np.errstate(divide='raise',invalid='raise'):
            for k in range(60):
                result['attempted_step']=k+1
                self.update(0.25)
                states=np.array([list(body.position)+list(body.velocity) for body,*_ in self.balls])
                if not np.isfinite(states).all():raise ValueError('Non-finite state')
        result['completed_steps']=60
    PhysicsEngine.run=bounded_run
    source=(ROOT/'original/main.py').read_text()
    module=ast.parse(source)
    class ReplacePaths(ast.NodeTransformer):
        def visit_Constant(self,node):
            if isinstance(node.value,str) and node.value.startswith('/Users/dong/Desktop/video/dataset/1/1/input'):
                tail=node.value.split('/input/',1)[1]
                return ast.copy_location(ast.Constant(str(inputs/tail)),node)
            return node
    module=ReplacePaths().visit(module);ast.fix_missing_locations(module)
    try:
        exec(compile(module,str(ROOT/'original/main.py'),'exec'),{'__name__':'__main__'})
        result['status']='passed'
    except Exception as error:
        result['status']='failed';result['error']=f'{type(error).__name__}: {error}'
        result['traceback']=traceback.format_exc()
    (ROOT/'results/original_run.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k not in ['initial_states','traceback']},indent=2))
    if result['status']=='failed':print(result['traceback'])

if __name__=='__main__':main()
