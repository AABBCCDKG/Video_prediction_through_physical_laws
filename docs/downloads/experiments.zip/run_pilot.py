from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import time
import cv2
import numpy as np
from scipy.optimize import linear_sum_assignment
import pymunk

ROOT=Path(__file__).resolve().parent
METHODS=['persistence','linear','quadratic','physics_constant_acceleration','physics_deceleration','physics_constant_velocity','physics_deceleration_no_contacts','physics_constant_velocity_no_contacts']

def detect(frame):
    gray=cv2.GaussianBlur(cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY),(9,9),2)
    circles=cv2.HoughCircles(gray,cv2.HOUGH_GRADIENT,dp=1.2,minDist=30,param1=50,param2=30,minRadius=15,maxRadius=50)
    return np.empty((0,3)) if circles is None else np.round(circles[0]).astype(float)

def track_clip(row):
    cache=ROOT/'data'/f"tracks_{row['scene_group']}_{row['variant']}.npz"
    if cache.exists():
        with np.load(cache) as z:return z['tracks'],z['radii'],z['counts'],z['frames']
    cap=cv2.VideoCapture(str(ROOT/'original'/row['path']))
    frames=[];detections=[]
    while True:
        ok,frame=cap.read()
        if not ok:break
        detections.append(detect(frame));frames.append(frame)
    cap.release()
    first=detections[0]
    first=first[np.lexsort((first[:,1],first[:,0]))]
    tracks=np.full((len(frames),len(first),2),np.nan);radius=np.full((len(frames),len(first)),np.nan)
    tracks[0]=first[:,:2];radius[0]=first[:,2]
    last=first[:,:2].copy();velocity=np.zeros_like(last)
    for k,det in enumerate(detections[1:],1):
        if not len(det):continue
        predicted=last+velocity
        cost=np.linalg.norm(predicted[:,None,:]-det[None,:,:2],axis=2)+2*np.abs(first[:,None,2]-det[None,:,2])
        objects,observations=linear_sum_assignment(cost)
        for obj,obs in zip(objects,observations):
            if cost[obj,obs]>60:continue
            new=det[obs,:2]
            velocity[obj]=new-last[obj];last[obj]=new
            tracks[k,obj]=new;radius[k,obj]=det[obs,2]
    frame_array=np.stack(frames)
    counts=np.array([len(d) for d in detections])
    np.savez_compressed(cache,tracks=tracks,radii=radius,counts=counts,frames=frame_array)
    return tracks,radius,counts,frame_array

def fit(tracks,T,fps,degree):
    t=(np.arange(T)-(T-1))/fps
    states=[]
    for obj in range(tracks.shape[1]):
        valid=np.isfinite(tracks[:T,obj]).all(axis=1)
        if valid.sum()<degree+1 or not np.isfinite(tracks[T-1,obj]).all():
            raise ValueError(f'Insufficient prefix object {obj}')
        coefficients=np.stack([np.polyfit(t[valid],tracks[:T,obj,d][valid],degree) for d in [0,1]],axis=1)
        pos=coefficients[-1]
        vel=coefficients[-2]
        accel=2*coefficients[0] if degree==2 else np.zeros(2)
        states.append((pos,vel,accel))
    return states

def simulate(states,radii,fps,H,mode):
    contacts=not mode.endswith('_no_contacts')
    mode=mode.removesuffix('_no_contacts')
    space=pymunk.Space();space.gravity=(0,0);space.iterations=30
    bodies=[]
    for (position,velocity,acceleration),radius in zip(states,radii):
        body=pymunk.Body(20,pymunk.moment_for_circle(20,0,float(radius)))
        body.position=tuple(position);body.velocity=tuple(velocity)
        shape=pymunk.Circle(body,float(radius));shape.elasticity=.95;shape.friction=.7
        if not contacts:shape.filter=pymunk.ShapeFilter(mask=0)
        space.add(body,shape);bodies.append(body)
    predictions=[]
    step=1/(fps*4)
    for h in range(H):
        for _ in range(4):
            for body,(_,_,acceleration) in zip(bodies,states):
                velocity=np.array(body.velocity)
                if mode=='physics_constant_acceleration':velocity=velocity+acceleration*step
                elif mode=='physics_deceleration':
                    speed=np.linalg.norm(velocity);decel=np.linalg.norm(acceleration)
                    if speed>1e-8:velocity=velocity*max(0,1-decel*step/speed)
                body.velocity=tuple(velocity)
            space.step(step)
        predictions.append(np.array([body.position for body in bodies]))
    result=np.stack(predictions)
    if not np.isfinite(result).all():raise ValueError('Non-finite physics predictions')
    return result

def overlap(predictions,radii):
    depths=[]
    for i in range(len(radii)):
        for j in range(i):
            radius=radii[i]+radii[j]
            distance=np.linalg.norm(predictions[:,i]-predictions[:,j],axis=1)
            depths.append(np.maximum(0,radius-distance)/radius)
    return float(np.mean(np.stack(depths))) if depths else 0.

def validation():
    states=[(np.array([0.,0.]),np.array([1.,0.]),np.zeros(2))]
    p=simulate(states,[1.],60,30,'physics_constant_velocity')
    assert np.allclose(p[-1,0],[.5,0],atol=1e-6),p[-1]
    states=[(np.array([0.,0.]),np.array([4.,0.]),np.array([-20.,0.]))]
    p=simulate(states,[.1],60,60,'physics_deceleration')
    assert np.all(np.diff(p[:,0,0])>=-1e-8)
    states=[(np.array([0.,0.]),np.array([4.,0.]),np.zeros(2)),(np.array([3.,0.]),np.zeros(2),np.zeros(2))]
    p=simulate(states,[.5,.5],60,90,'physics_constant_velocity')
    assert p[-1,1,0]>3.5 and p[-1,0,0]<p[-1,1,0]
    p=simulate(states,[.5,.5],60,90,'physics_constant_velocity_no_contacts')
    assert np.allclose(p[-1,:,0],[6.,3.],atol=1e-6),p[-1]
    print('Validation passed: aligned time, stopping without reversal, contact response, disabled-contact straight trajectories',flush=True)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--horizon',type=int,default=30)
    args=parser.parse_args();cv2.setNumThreads(2);validation()
    manifest=json.loads((ROOT/'data/video_manifest.json').read_text())
    rows=[];failures=[];start=time.perf_counter()
    for row in manifest:
        T=row['input_frames_in_repository'];H=min(args.horizon,row['frames']-T);fps=row['fps']
        try:
            tracks,radius,counts,frames=track_clip(row)
            radii=np.nanmedian(radius[:T],axis=0)
            linear=fit(tracks,T,fps,1);quadratic=fit(tracks,T,fps,2)
            times=np.arange(1,H+1)/fps
            predictions={
                'persistence':np.repeat(tracks[T-1:T],H,axis=0),
                'linear':np.stack([pos+times[:,None]*vel for pos,vel,_ in linear],axis=1),
                'quadratic':np.stack([pos+times[:,None]*vel+.5*times[:,None]**2*accel for pos,vel,accel in quadratic],axis=1)}
            for method in METHODS[3:]:predictions[method]=simulate(quadratic,radii,fps,H,method)
            targets=tracks[T:T+H];valid=np.isfinite(targets).all(axis=2)
            moving=np.array([np.linalg.norm(velocity)/fps>1.0 for _,velocity,_ in linear])
            for method,prediction in predictions.items():
                error=np.linalg.norm(prediction-targets,axis=2)
                moving_valid=valid & moving[None,:]
                rows.append({'scene_group':row['scene_group'],'variant':row['variant'],'method':method,'input_frames':T,'horizon':H,'objects':len(radii),'target_coverage':float(valid.mean()),'prefix_moving_objects':int(moving.sum()),'moving_ADE_px':float(error[moving_valid].mean()) if moving_valid.any() else None,'ADE_px':float(error[valid].mean()),'FDE_px':float(error[-1,valid[-1]].mean()) if valid[-1].any() else None,'mean_normalized_overlap':overlap(prediction,radii)})
            np.savez_compressed(ROOT/'results'/f"predictions_{row['scene_group']}_{row['variant']}.npz",target=targets,radii=radii,**predictions)
            if row['scene_group']==1 and row['variant']==1:
                panels=[]
                for label in ['target','persistence','linear','quadratic','physics_deceleration']:
                    frame=frames[T+H-1].copy()
                    coords=targets[-1] if label=='target' else predictions[label][-1]
                    for p,r in zip(coords,radii):
                        if np.isfinite(p).all():cv2.circle(frame,tuple(np.round(p).astype(int)),int(round(r)),(0,0,255),3)
                    cv2.putText(frame,label,(30,45),cv2.FONT_HERSHEY_SIMPLEX,1,(255,255,255),2)
                    panels.append(cv2.resize(frame,(640,360)))
                cv2.imwrite(str(ROOT/'results/scene1_prediction_overlay.jpg'),np.concatenate(panels,axis=0))
            print(f"Finished {row['scene_group']}/{row['variant']}: {len(radii)} objects, target coverage={valid.mean():.3f}",flush=True)
        except Exception as e:
            failures.append({'scene_group':row['scene_group'],'variant':row['variant'],'error':f'{type(e).__name__}: {e}'})
            print('FAIL',failures[-1],flush=True)
    with (ROOT/'results/pilot_metrics.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else []);writer.writeheader();writer.writerows(rows)
    aggregates={}
    for method in METHODS:
        selected=[r for r in rows if r['method']==method]
        by_scene={g:np.mean([r['ADE_px'] for r in selected if r['scene_group']==g]) for g in sorted({r['scene_group'] for r in selected})}
        aggregates[method]={'clips':len(selected),'scene_mean_ADE_px':float(np.mean(list(by_scene.values()))) if by_scene else None,'clip_mean_FDE_px':float(np.mean([r['FDE_px'] for r in selected if r['FDE_px'] is not None])) if selected else None,'per_scene_ADE_px':by_scene}
    summary={'status':'diagnostic_only','label_source':'Same Hough detector with causal Hungarian association; not independent ground truth','horizon_frames':args.horizon,'all_visible_objects_including_stationary':True,'split':'No learning or test-data tuning; prototype contact constants','boundaries':'Not modeled','source_prefixes':'Repository input lengths, unverified interaction timing','runtime_seconds':time.perf_counter()-start,'aggregates':aggregates,'failures':failures}
    (ROOT/'results/pilot_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':main()
