from __future__ import annotations
import csv
import hashlib
import json
from pathlib import Path
import cv2
import numpy as np
from scipy.optimize import linear_sum_assignment
from run_pilot import detect,fit,simulate,overlap,METHODS
from build_labels import components

ROOT=Path(__file__).resolve().parent

def prefix_tracks(frames,T):
    observations=[detect(frame) for frame in frames[:T]]
    last=observations[-1]
    last=last[np.lexsort((last[:,1],last[:,0]))]
    positions=np.full((T,len(last),2),np.nan)
    radius=np.full((T,len(last)),np.nan)
    positions[-1]=last[:,:2];radius[-1]=last[:,2]
    next_position=positions[-1].copy();backward_velocity=np.zeros_like(next_position)
    for k in range(T-2,-1,-1):
        obs=observations[k]
        if not len(obs):continue
        expected=next_position+backward_velocity
        distances=np.linalg.norm(expected[:,None,:]-obs[None,:,:2],axis=2)
        cost=distances+2*np.abs(last[:,None,2]-obs[None,:,2])
        objects,dets=linear_sum_assignment(cost)
        for obj,det in zip(objects,dets):
            if distances[obj,det]>60:continue
            positions[k,obj]=obs[det,:2];radius[k,obj]=obs[det,2]
            backward_velocity[obj]=positions[k,obj]-next_position[obj]
            next_position[obj]=positions[k,obj]
    # An endpoint detection supplies a valid static fallback when a fit lacks enough observations.
    for obj in range(len(last)):
        valid=np.isfinite(positions[:,obj]).all(axis=1)
        if valid.sum()<3:
            positions[:,obj]=last[obj,:2];radius[:,obj]=last[obj,2]
    return positions,radius

def rgb(frame):return cv2.cvtColor(cv2.resize(frame,(160,90),interpolation=cv2.INTER_AREA),cv2.COLOR_BGR2RGB)

def render(prefix,positions,radii,predictions):
    # Fixed observed appearance renderer; no target pixel enters a forecast.
    height,width=prefix.shape[1:3];last=prefix[-1]
    mask=np.zeros((height,width),np.uint8)
    patches=[]
    for p,r in zip(positions,radii):
        if not np.isfinite(p).all():patches.append(None);continue
        x,y=np.round(p).astype(int);rr=int(np.ceil(r+4))
        cv2.circle(mask,(x,y),rr,255,-1)
        x0=max(0,x-rr);y0=max(0,y-rr);x1=min(width,x+rr+1);y1=min(height,y+rr+1)
        patch=last[y0:y1,x0:x1].copy()
        yy,xx=np.ogrid[y0:y1,x0:x1];alpha=((xx-x)**2+(yy-y)**2<=r*r).astype(np.uint8)*255
        patches.append((patch,alpha,np.array([x0,y0])))
    background=cv2.inpaint(last,mask,5,cv2.INPAINT_TELEA)
    outputs=[]
    for centers in predictions:
        frame=background.copy()
        for center,position,patch in zip(centers,positions,patches):
            if patch is None:continue
            crop,alpha,origin=patch
            displacement=np.round(center-position).astype(int)
            x0,y0=origin+displacement;h,w=crop.shape[:2]
            a=max(0,x0);b=max(0,y0);c=min(width,x0+w);d=min(height,y0+h)
            if a>=c or b>=d:continue
            source=crop[b-y0:d-y0,a-x0:c-x0];weight=alpha[b-y0:d-y0,a-x0:c-x0].astype(float)/255
            frame[b:d,a:c]=(frame[b:d,a:c]*(1-weight[:,:,None])+source*weight[:,:,None]).astype('uint8')
        outputs.append(rgb(frame))
    return np.stack(outputs)

def contact_events(predictions,radii):
    events=[]
    for i in range(len(radii)):
        for j in range(i):
            d=np.linalg.norm(predictions[:,i]-predictions[:,j],axis=1)
            near=d<=radii[i]+radii[j]+8
            for k in range(len(near)):
                if near[k] and (k==0 or not near[k-1]):events.append((k,[j,i]))
    return events

def score_events(predictions,radii,truth,T,H):
    reference=[(e['frame']-T,e['objects']) for e in truth if T<=e['frame']<T+H]
    forecast=contact_events(predictions,radii)
    matched=set();errors=[]
    for k,pair in reference:
        choices=[(abs(f-k),n) for n,(f,p) in enumerate(forecast) if n not in matched and p==pair and abs(f-k)<=3]
        if choices:
            err,n=min(choices);matched.add(n);errors.append(err)
    tp=len(matched);return tp,len(forecast)-tp,len(reference)-tp,float(np.mean(errors)) if errors else None

def image_geometry(forecasts,reference,radii):
    predictions=np.full(reference.shape,np.nan)
    h,w=720,1280
    for k,frame in enumerate(forecasts):
        up=cv2.resize(cv2.cvtColor(frame,cv2.COLOR_RGB2BGR),(w,h),interpolation=cv2.INTER_LINEAR)
        obs=components(up)
        valid=np.isfinite(reference[k]).all(axis=1)
        objects=np.flatnonzero(valid)
        if not obs or not len(objects):continue
        centers=np.array([d['center'] for d in obs])
        cost=np.linalg.norm(reference[k,objects,None,:]-centers[None,:,:],axis=2)
        a,b=linear_sum_assignment(cost)
        for i,j in zip(a,b):
            obj=objects[i]
            if cost[i,j]<max(3*radii[obj],100):predictions[k,obj]=centers[j]
    return predictions

def main():
    protocol=json.loads((ROOT/'protocol.json').read_text());manifest=json.loads((ROOT/'data/video_manifest.json').read_text())
    annotations={f"{r['scene_group']}_{r['variant']}":r for r in json.loads((ROOT/'data/labels/manifest.json').read_text())}
    out=ROOT/'results/formal';out.mkdir(exist_ok=True)
    rows=[];label_mapping=[]
    for row in manifest:
        key=f"{row['scene_group']}_{row['variant']}";T=row['input_frames_in_repository'];fps=row['fps']
        with np.load(ROOT/f'data/tracks_{key}.npz') as z:tracks=z['tracks'];observed_radii=z['radii'];frames=z['frames']
        tracks,observed_radii=prefix_tracks(frames,T)
        with np.load(ROOT/f'data/labels/{key}.npz') as z:measured=z['centers'];radii=z['radii'];status=z['status']
        prefix_reference=measured[T-1]
        prefix_valid=np.isfinite(prefix_reference).all(axis=1)
        prefix_prediction=tracks[T-1]
        pred_valid=np.isfinite(prefix_prediction).all(axis=1)
        if not prefix_valid.all():print('Unavailable prefix labels',key,flush=True)
        mapped=np.full(len(radii),-1,dtype=int)
        source_indices=np.flatnonzero(pred_valid);target_indices=np.flatnonzero(prefix_valid)
        cost=np.linalg.norm(prefix_reference[target_indices,None,:]-prefix_prediction[source_indices][None,:,:],axis=2)
        aa,bb=linear_sum_assignment(cost)
        for a,b in zip(aa,bb):
            if cost[a,b]<50:mapped[target_indices[a]]=source_indices[b]
        label_mapping.append({'clip':key,'label_objects':len(radii),'matched_prefix_objects':int((mapped>=0).sum()),'mapping':mapped.tolist()})
        linear_states=fit(tracks,T,fps,1);quadratic_states=fit(tracks,T,fps,2)
        pred_radii=np.nanmedian(observed_radii[:T],axis=0)
        Hmax=min(60,len(frames)-T);times=np.arange(1,Hmax+1)/fps
        forecasts={'persistence':np.repeat(tracks[T-1:T],Hmax,axis=0),
                   'linear':np.stack([p+times[:,None]*v for p,v,_ in linear_states],axis=1),
                   'quadratic':np.stack([p+times[:,None]*v+.5*times[:,None]**2*a for p,v,a in quadratic_states],axis=1)}
        for method in METHODS[3:]:forecasts[method]=simulate(quadratic_states,pred_radii,fps,Hmax,method)
        rgb_targets=np.stack([rgb(f) for f in frames[T:T+Hmax]])
        rgb_forecasts={method:(np.repeat(rgb(frames[T-1])[None],Hmax,axis=0) if method=='persistence' else render(frames[:T],tracks[T-1],pred_radii,p)) for method,p in forecasts.items()}
        split='train' if row['scene_group'] in protocol['train_groups'] else 'validation' if row['scene_group'] in protocol['validation_groups'] else 'test'
        for seed in protocol['convlstm']['seeds']:
            p=out/f'convlstm_seed{seed}/forecasts.npz'
            if split!='train':
                with np.load(p) as z:rgb_forecasts[f'convlstm_seed{seed}']=z[key]
        for H in protocol['horizons_frames']:
            if H>Hmax:continue
            reference=measured[T:T+H];valid=np.isfinite(reference).all(axis=2)
            reference_displacement=np.linalg.norm(reference-prefix_reference[None,:,:],axis=2)
            moving=(np.nanmax(reference_displacement,axis=0)>5)
            for method,images in rgb_forecasts.items():
                images=images[:H]
                if method.startswith('convlstm'):
                    pred=image_geometry(images,reference,radii)
                    pred_miss=valid & ~np.isfinite(pred).all(axis=2)
                else:
                    pred=np.full(reference.shape,np.nan)
                    for obj,index in enumerate(mapped):
                        if index>=0:pred[:,obj]=forecasts[method][:H,index]
                    pred_miss=valid & ~np.isfinite(pred).all(axis=2)
                error=np.linalg.norm(pred-reference,axis=2)
                # Penalize prediction misses; unavailable image measurements are reported separately.
                penalty=np.hypot(row['width'],row['height'])
                error[pred_miss]=penalty
                ade=float(np.mean(error[valid]));final=valid[-1]
                fde=float(np.mean(error[-1,final])) if final.any() else None
                moving_valid=valid & moving[None,:]
                mse=float(np.mean((images.astype(float)/255-rgb_targets[:H].astype(float)/255)**2))
                tp,fp,fn,timing=(None,None,None,None) if method.startswith('convlstm') else score_events(pred,radii,annotations[key]['candidate_events'],T,H)
                penetration=[]
                if not method.startswith('convlstm'):
                    for i in range(len(radii)):
                        for j in range(i):
                            d=np.linalg.norm(pred[:,i]-pred[:,j],axis=1);depth=np.maximum(0,radii[i]+radii[j]-d)/(radii[i]+radii[j])
                            penetration.extend(depth[np.isfinite(depth)].tolist())
                overlap_rate=float(np.mean(np.array(penetration)>.1)) if penetration else None
                mean_depth=float(np.mean(penetration)) if penetration else None
                rows.append({'clip':key,'scene_group':row['scene_group'],'variant':row['variant'],'split':split,'method':method,'horizon':H,'input_frames':T,'objects':len(radii),'label_coverage':float(valid.mean()),'prediction_miss_rate':float(pred_miss.sum()/max(1,valid.sum())),'ADE_px':ade,'FDE_px':fde,'moving_ADE_px':float(error[moving_valid].mean()) if moving_valid.any() else None,'RGB_MSE':mse,'PSNR_dB':-10*np.log10(max(mse,1e-12)),'overlap_pair_time_rate':overlap_rate,'mean_normalized_penetration':mean_depth,'contact_TP':tp,'contact_FP':fp,'contact_FN':fn,'contact_timing_frames':timing})
        np.savez_compressed(out/f'rgb_forecasts_{key}.npz',target=rgb_targets,**rgb_forecasts)
        np.savez_compressed(out/f'geometry_forecasts_{key}.npz',target=measured[T:T+Hmax],radii=radii,mapping=mapped,**forecasts)
        print('Scored',key,split,'mapped',int((mapped>=0).sum()),'/',len(radii),flush=True)
    with (out/'metrics.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (out/'prefix_mapping.json').write_text(json.dumps(label_mapping,indent=2))
    summary={}
    for split in ['train','validation','test']:
        summary[split]={}
        for H in protocol['horizons_frames']:
            summary[split][H]={}
            for method in sorted({r['method'] for r in rows if r['split']==split}):
                selected=[r for r in rows if r['split']==split and r['horizon']==H and r['method']==method]
                if not selected:continue
                tp=sum(r['contact_TP'] for r in selected if r['contact_TP'] is not None);fp=sum(r['contact_FP'] for r in selected if r['contact_FP'] is not None);fn=sum(r['contact_FN'] for r in selected if r['contact_FN'] is not None)
                summary[split][H][method]={name:float(np.mean([r[name] for r in selected if r[name] is not None])) if any(r[name] is not None for r in selected) else None for name in ['ADE_px','FDE_px','moving_ADE_px','RGB_MSE','PSNR_dB','label_coverage','prediction_miss_rate','overlap_pair_time_rate','mean_normalized_penetration']}
                summary[split][H][method].update({'clips':len(selected),'contact_TP':tp,'contact_FP':fp,'contact_FN':fn,'contact_F1':2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else None})
    (out/'summary.json').write_text(json.dumps({'protocol_sha256':hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest(),'results':summary,'labels':'separate foreground measurements with reviewed keyframes; no exact game-state ground truth','neural_center_evaluation':'target-anchored assignment at each frame and 100px/3r gate; misses penalized by frame diagonal; diagnostic','scene_limit':'two test groups after prior exploratory inspection'},indent=2))
    print(json.dumps(summary['test'][30],indent=2),flush=True)
if __name__=='__main__':main()
