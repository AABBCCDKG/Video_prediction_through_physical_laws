from __future__ import annotations
import json
from pathlib import Path
import cv2
import numpy as np
from scipy.optimize import linear_sum_assignment
from PIL import Image,ImageDraw

ROOT=Path(__file__).resolve().parent

def foreground(frame):
    hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    mask=((hsv[:,:,0]<35)|(hsv[:,:,0]>90)|(hsv[:,:,1]<60)|(hsv[:,:,2]<65)).astype('uint8')*255
    return cv2.morphologyEx(mask,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8))

def components(frame):
    mask=foreground(frame)
    count,labels,stats,_=cv2.connectedComponentsWithStats(mask)
    found=[]
    for i in range(1,count):
        x,y,w,h,area=stats[i]
        if not 1400<=area<=6500 or not .65<w/h<1.5 or w<35 or h<35 or w>100 or h>100:continue
        if x<3 or y<3 or x+w>frame.shape[1]-3 or y+h>frame.shape[0]-3:continue
        local=(labels[y:y+h,x:x+w]==i).astype('uint8')*255
        contours,_=cv2.findContours(local,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
        if not contours:continue
        contour=max(contours,key=cv2.contourArea)
        if len(contour)<5:continue
        (cx,cy),(a,b),_=cv2.fitEllipse(contour)
        if not 20<=min(a,b)/2<=45 or max(a,b)/min(a,b)>1.35:continue
        radius=(a+b)/4
        fill=area/(np.pi*radius**2)
        if not .65<fill<1.3:continue
        yy,xx=np.ogrid[:h,:w];inner=(xx-cx)**2+(yy-cy)**2<(radius*.6)**2
        crop=frame[y:y+h,x:x+w];v=cv2.cvtColor(crop,cv2.COLOR_BGR2HSV)[:,:,2]
        if np.mean(v[inner])<45:continue
        color=np.mean(crop[inner],axis=0)
        found.append({'center':np.array([cx+x,cy+y]),'radius':radius,'color':color,'fill':float(fill)})
    return found

def nearest_template(frame,previous_frame,center,radius,predicted):
    r=int(round(radius+4));height,width=frame.shape[:2]
    x,y=np.round(center).astype(int)
    if x-r<0 or y-r<0 or x+r>=width or y+r>=height:return None
    patch=previous_frame[y-r:y+r+1,x-r:x+r+1]
    px,py=np.round(predicted).astype(int);margin=35
    x0=max(0,px-r-margin);y0=max(0,py-r-margin);x1=min(width,px+r+margin+1);y1=min(height,py+r+margin+1)
    search=frame[y0:y1,x0:x1]
    if search.shape[0]<patch.shape[0] or search.shape[1]<patch.shape[1]:return None
    score=cv2.matchTemplate(search,patch,cv2.TM_CCOEFF_NORMED);_,quality,_,loc=cv2.minMaxLoc(score)
    if quality<.50:return None
    return np.array([x0+loc[0]+r,y0+loc[1]+r],dtype=float),float(quality)

def main():
    cv2.setNumThreads(2);manifest=json.loads((ROOT/'data/video_manifest.json').read_text())
    out=ROOT/'data/labels';out.mkdir(exist_ok=True);reviews=ROOT/'results/label_review';reviews.mkdir(exist_ok=True)
    summaries=[]
    for row in manifest:
        g=row['scene_group'];v=row['variant'];T=row['input_frames_in_repository']
        with np.load(ROOT/f'data/tracks_{g}_{v}.npz') as z:frames=z['frames']
        initial=components(frames[0])
        if (g,v)==(10,2):
            # Image-reviewed cue-ball seed: low-contrast foreground joins the rail mask.
            center=np.array([185.,442.]);radius=31.
            x,y=center.astype(int);color=frames[0,y-10:y+11,x-10:x+11].mean(axis=(0,1))
            initial.append({'center':center,'radius':radius,'color':color,'fill':1.0})
        initial=sorted(initial,key=lambda x:x['center'][0])
        tracks=np.full((len(frames),len(initial),2),np.nan);status=np.zeros((len(frames),len(initial)),dtype=np.uint8)
        radii=np.array([x['radius'] for x in initial]);colors=np.array([x['color'] for x in initial])
        if not len(initial):raise RuntimeError(f'No objects {g}/{v}')
        tracks[0]=np.array([x['center'] for x in initial]);status[0]=1
        last=tracks[0].copy();velocity=np.zeros_like(last);last_visible=np.ones(len(initial),dtype=bool)
        for k in range(1,len(frames)):
            candidates=components(frames[k]);predicted=last+velocity
            assigned=set()
            if candidates:
                centers=np.array([x['center'] for x in candidates]);candidate_radii=np.array([x['radius'] for x in candidates]);candidate_colors=np.array([x['color'] for x in candidates])
                spatial=np.linalg.norm(predicted[:,None,:]-centers[None,:,:],axis=2)
                color=np.linalg.norm(colors[:,None,:]-candidate_colors[None,:,:],axis=2)
                cost=spatial+3*np.abs(radii[:,None]-candidate_radii[None,:])+color*.05
                objs,dets=linear_sum_assignment(cost)
                for obj,det in zip(objs,dets):
                    if spatial[obj,det]>45 or cost[obj,det]>70:continue
                    point=centers[det];tracks[k,obj]=point;status[k,obj]=1;assigned.add(obj)
            for obj in range(len(initial)):
                if obj in assigned:continue
                if predicted[obj,0]-radii[obj]<2 or predicted[obj,1]-radii[obj]<2 or predicted[obj,0]+radii[obj]>=row['width']-2 or predicted[obj,1]+radii[obj]>=row['height']-2:
                    last[obj]=predicted[obj];last_visible[obj]=False;continue
                if last_visible[obj]:
                    estimate=nearest_template(frames[k],frames[k-1],last[obj],radii[obj],predicted[obj])
                    if estimate:
                        point,quality=estimate
                        if point[0]-radii[obj]>2 and point[1]-radii[obj]>2 and point[0]+radii[obj]<row['width']-2 and point[1]+radii[obj]<row['height']-2:
                            px,py=np.round(point).astype(int);rr=int(round(radii[obj]*.65))
                            support=foreground(frames[k][py-rr:py+rr+1,px-rr:px+rr+1]).mean()/255
                            if support>.40:tracks[k,obj]=point;status[k,obj]=2
                if not np.isfinite(tracks[k,obj]).all():
                    last[obj]=predicted[obj];last_visible[obj]=False;continue
                step=tracks[k,obj]-last[obj]
                velocity[obj]=step if last_visible[obj] else velocity[obj]
                last[obj]=tracks[k,obj];last_visible[obj]=True
            for obj in assigned:
                step=tracks[k,obj]-last[obj];velocity[obj]=step if last_visible[obj] else velocity[obj]
                last[obj]=tracks[k,obj];last_visible[obj]=True
        if (g,v)==(10,1):radii[0]=31.0
        # Foreground targets remain unavailable during clipping or unmeasured occlusion.
        np.savez_compressed(out/f'{g}_{v}.npz',centers=tracks,radii=radii,status=status)
        events=[]
        for i in range(len(initial)):
            for j in range(i):
                dist=np.linalg.norm(tracks[:,i]-tracks[:,j],axis=1);valid=np.isfinite(dist)
                near=valid & (dist<radii[i]+radii[j]+8)
                for k in range(1,len(frames)):
                    if near[k] and not near[k-1] and valid[k-1] and dist[k]<dist[k-1]:events.append({'frame':k,'objects':[j,i],'source':'image-derived near-contact onset','distance':float(dist[k])})
        if (g,v)==(4,1):events.insert(0,{'frame':3,'objects':[2,4],'source':'visual contact review of frames1-4','uncertainty_frames':2})
        if (g,v)==(8,1):events=[{'frame':25,'objects':[0,2],'source':'visual contact review of frames24-26','uncertainty_frames':2}]
        if (g,v)==(10,1):events=[{'frame':26,'objects':[0,1],'source':'visual review of velocity transfer at frames25-27','uncertainty_frames':2}]
        for event in events:event.setdefault('uncertainty_frames',2)
        keyframes=sorted(set([0,max(0,T-1),min(T+14,len(frames)-1),min(T+29,len(frames)-1),min(T+59,len(frames)-1),*([events[0]['frame']] if events else [])]))
        canvas=Image.new('RGB',(1280,400*((len(keyframes)+1)//2)),'#eee');draw=ImageDraw.Draw(canvas)
        for n,k in enumerate(keyframes):
            frame=frames[k].copy()
            for obj,(p,r) in enumerate(zip(tracks[k],radii)):
                if np.isfinite(p).all():
                    cv2.circle(frame,tuple(np.round(p).astype(int)),int(round(r)),(0,255,255) if status[k,obj]==1 else (255,0,255),2)
                    cv2.putText(frame,str(obj),tuple(np.round(p-[0,r+5]).astype(int)),cv2.FONT_HERSHEY_SIMPLEX,.8,(0,255,255),2)
            frame=cv2.resize(frame,(640,360));x=(n%2)*640;y=(n//2)*400+25
            canvas.paste(Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)),(x,y));draw.text((x+10,y-20),f'{g}/{v} frame={k} / objects={len(initial)}',fill='black')
        canvas.save(reviews/f'{g}_{v}.jpg')
        summary={'scene_group':g,'variant':v,'objects':len(initial),'radii':radii.tolist(),'full_coverage':float((status>0).mean()),'horizon30_coverage':float((status[T:T+30]>0).mean()),'component_fraction':float((status==1).mean()),'template_fraction':float((status==2).mean()),'candidate_events':events,'review_status':'keyframe_reviewed; regenerated_with_visibility_checks','measurement':'HSV foreground components + ellipse fitting; local template fallback, no Hough centers used','review_scope':'assistant visual review of prefix endpoints and +15/+30/+60 frames; no exported game states or external human labeling'}
        summaries.append(summary);print(f'{g}/{v} objects={len(initial)} coverage={summary["horizon30_coverage"]:.3f} events={events}',flush=True)
    (out/'manifest.json').write_text(json.dumps(summaries,indent=2))
if __name__=='__main__':main()
