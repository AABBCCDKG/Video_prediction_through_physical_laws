from __future__ import annotations
import csv
import json
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent
NAMES={'persistence':'Persistence','linear':'Linear extrapolation','quadratic':'Quadratic extrapolation','physics_constant_acceleration':'Physics + constant acceleration','physics_constant_velocity':'Physics + constant velocity','physics_constant_velocity_no_contacts':'Same state, no contacts','physics_deceleration':'Physics + deceleration','physics_deceleration_no_contacts':'Deceleration, no contacts'}

def main():
 out=ROOT/'results/formal';summary=json.loads((out/'summary.json').read_text())
 r=summary['results'];data=list(csv.DictReader((out/'metrics.csv').open()))
 neural=[r['test']['30'][f'convlstm_seed{s}'] for s in [0,1,2]]
 group_rows={}
 for g in [9,10]:
  group_rows[g]={}
  for method in NAMES:
   rows=[x for x in data if int(x['scene_group'])==g and x['method']==method and x['horizon']=='30']
   group_rows[g][method]={metric:float(np.mean([float(x[metric]) for x in rows if x[metric]])) for metric in ['ADE_px','moving_ADE_px','RGB_MSE','PSNR_dB']}
 report={'heldout_at_30':r['test']['30'],'validation_at_30':r['validation']['30'],'per_test_group':group_rows,'convlstm_seed_mean':{metric:float(np.mean([x[metric] for x in neural])) for metric in ['RGB_MSE','PSNR_dB','prediction_miss_rate']},'convlstm_seed_sd':{metric:float(np.std([x[metric] for x in neural],ddof=1)) for metric in ['RGB_MSE','PSNR_dB','prediction_miss_rate']},'horizons':{h:r['test'][h] for h in ['15','30','60']},'evidence_scope':'exploratory case study: two grouped test scenes, separately measured keyframe-reviewed image positions'}
 (out/'report.json').write_text(json.dumps(report,indent=2))
 lines=['# Existing-scene grouped experiment results','','All results below were computed from fixed scene partitions: groups1–6 train,7–8 validation,9–10 evaluation. Both variants remain grouped. Existing scenes were examined in the earlier pilot, and neural training budget was extended from400 to2000 updates after validation loss continued improving. This is exploratory evaluation; no untouched external test set is claimed.','','## 30-frame geometry comparison','','Geometry is measured in1280×720 pixels against separate HSV segmentation/ellipse estimates and local tracking, with assistant-reviewed keyframes and explicit unavailable measurements. It is not exact simulator ground truth.','','| Method | ADE px | FDE px | Moving ADE px | Pair-time overlap >10% |','|---|---:|---:|---:|---:|']
 for method,name in NAMES.items():
  x=r['test']['30'][method]
  lines.append(f"| {name} | {x['ADE_px']:.2f} | {x['FDE_px']:.2f} | {x['moving_ADE_px']:.2f} | {100*x['overlap_pair_time_rate']:.2f}% |")
 lines.extend(['','The moving cohort includes objects whose measured future displacement exceeds5px; this is a reporting stratum and does not provide inference inputs. Missing predictions are charged the image diagonal in archived end-to-end scores. Unavailable target measurements are excluded and their coverage is reported.','','## Complete RGB comparison','','All methods use160×90 RGB targets; classical methods share an observed-patch translation/inpainting renderer. ConvLSTM produces its own frames autoregressively.','','| Method | RGB MSE | Mean per-clip PSNR dB |','|---|---:|---:|'])
 for method in ['persistence','linear','quadratic','physics_constant_velocity','physics_constant_velocity_no_contacts','physics_deceleration']:
  x=r['test']['30'][method];lines.append(f"| {NAMES[method]} | {x['RGB_MSE']:.6f} | {x['PSNR_dB']:.2f} |")
 for s in [0,1,2]:
  x=r['test']['30'][f'convlstm_seed{s}'];lines.append(f"| ConvLSTM seed{s} | {x['RGB_MSE']:.6f} | {x['PSNR_dB']:.2f} |")
 lines.extend(['',f"ConvLSTM across seeds: MSE {report['convlstm_seed_mean']['RGB_MSE']:.6f} ± {report['convlstm_seed_sd']['RGB_MSE']:.6f}; mean PSNR {report['convlstm_seed_mean']['PSNR_dB']:.2f} ± {report['convlstm_seed_sd']['PSNR_dB']:.2f} dB. Seed SD describes optimization variability, not uncertainty across scenes.",'','The frame background dominates RGB MSE; geometry and motion-object reporting remain necessary. Neural detector-based ADE is retained only in raw diagnostic files because blob-extraction failures make it detector-dependent. The primary neural comparison is complete RGB MSE/PSNR plus qualitative predictions.','','## Per-scene results','','| Scene | CV physics ADE px | Same state without contacts | Deceleration physics | Quadratic |','|---|---:|---:|---:|---:|'])
 for g in [9,10]:
  x=group_rows[g];lines.append(f"| {g} | {x['physics_constant_velocity']['ADE_px']:.2f} | {x['physics_constant_velocity_no_contacts']['ADE_px']:.2f} | {x['physics_deceleration']['ADE_px']:.2f} | {x['quadratic']['ADE_px']:.2f} |")
 lines.extend(['','Do not claim statistical significance or broad generalization from two evaluation groups. Candidate near-contact metrics are descriptive and can count a pass-through as contact; they are not a substitute for displacement or penetration measurements. Full event counts, label coverage, training logs, checkpoints, and per-clip numbers are archived.'])
 (out/'RESULTS.md').write_text('\n'.join(lines)+'\n')
 # Figure with actual frame predictions at h=30 for all four evaluated clips.
 methods=['target','physics_constant_velocity','convlstm_seed0']
 font_path='/System/Library/Fonts/Supplemental/Times New Roman.ttf'
 try:font=ImageFont.truetype(font_path,32)
 except OSError:font=ImageFont.load_default()
 canvas=Image.new('RGB',(3*480+110,4*300+50),'white');draw=ImageDraw.Draw(canvas)
 headers=['Recorded future','Physics (CV)','ConvLSTM (seed 0)']
 for col,header in enumerate(headers):draw.text((115+col*480,7),header,fill='black',font=font)
 for row,key in enumerate(['9_1','9_2','10_1','10_2']):
  z=np.load(out/f'rgb_forecasts_{key}.npz')
  draw.text((7,120+row*300),key.replace('_','/'),fill='black',font=font)
  for col,method in enumerate(methods):
   im=Image.fromarray(z[method][29]).resize((480,270))
   canvas.paste(im,(110+col*480,50+row*300))
 canvas.save(out/'qualitative_predictions.png')
 # Standard vector plot for paper/export.
 try:
  import matplotlib
  matplotlib.use('Agg')
  matplotlib.rcParams['pdf.fonttype']=42
  matplotlib.rcParams['ps.fonttype']=42
  import matplotlib.pyplot as plt
  fig,ax=plt.subplots(figsize=(6.0,3.2))
  for method,name in [('quadratic','Quadratic'),('physics_constant_velocity_no_contacts','No contacts'),('physics_constant_velocity','Physics (CV)'),('physics_deceleration','Physics (deceleration)')]:
   ax.plot([15,30,60],[r['test'][str(h)][method]['ADE_px'] for h in [15,30,60]],marker='o',label=name)
  ax.set(xlabel='Forecast horizon (frames)',ylabel='Image-measured ADE (pixels)',xticks=[15,30,60]);ax.grid(alpha=.2);ax.legend(frameon=False,fontsize=8);fig.tight_layout();fig.savefig(out/'horizon_ade.pdf');fig.savefig(out/'horizon_ade.png',dpi=170);plt.close(fig)
 except ImportError:pass
 print(json.dumps({'geometry':r['test']['30']['physics_constant_velocity'],'neural':report['convlstm_seed_mean'],'scene_results':group_rows},indent=2))
if __name__=='__main__':main()
